    def inject_rtcm(self, data: bytes) -> bool:
        """Forward raw RTCM3 correction bytes to the TAU1308 GNSS rover.

        Called by tools/serial_telemetry.py which owns the SiK radio port and
        receives RTCM from the ground station dashboard via the uplink.

        Returns True if bytes were forwarded, False if GPS is unavailable.
        The _Gps instance holds a reference to the live TAU1308 gnss object
        via self._gps._gnss; we access it under the GPS lock to avoid a race
        with the GPS thread closing the driver on error.
        """
        try:
            gps = self._gps
            if gps is None or not gps.ok:
                return False
            gnss = getattr(gps, '_gnss', None)
            if gnss is None:
                return False
            gnss.send_rtcm(data)
            return True
        except Exception as e:
            log.debug("inject_rtcm error: %s", e)
            return False
