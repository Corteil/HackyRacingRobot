#!/usr/bin/env python3
"""
tools/serial_telemetry.py — SiK radio telemetry bridge for HackyRacingRobot.

Owns the SiK radio serial port exclusively, replacing gnss/rtcm_serial.py
when the SiK link is active.  Set [rtcm] disabled = true in robot.ini.

Downlink (robot → ground station)
----------------------------------
Newline-delimited JSON at [telemetry_radio] telemetry_hz (default 5 Hz).
LiDAR packets injected at 1 Hz when enabled (switchable at runtime).

Packet types ("t" field):

  {"t":"state","ts":1234.5,"mode":"MANUAL","rc":true,
   "drv":[0.0,0.0],
   "telem":{"v":12.1,"i":1.2,"bt":35.1,"lt":32.0,"rt":31.5,
            "lf":false,"rf":false,"hdg":180.0,"pit":2.1,"rol":-0.5},
   "gps":{"lat":52.123,"lon":0.456,"alt":10.2,"spd":0.0,"hdg":null,
          "fix":1,"fqn":"GPS","herr":null,"sats":8,"hdop":1.2,
          "ntrip":"connected"},
   "sys":{"cpu":18.5,"temp":55.0,"mem":42.1,"disk":12.3},
   "nav":{"st":"IDLE","gate":0,"wp":0,"dist":null,"bear":null,
          "berr":null,"tags":0},
   "flags":{"lidar_ok":true,"gps_ok":true,"cam_ok":true,
            "data_log":false,"speed":0.25}}

  {"t":"lidar","ts":1234.5,
   "a":[0,5,10,...],    <- angles in degrees (integers, every lidar_step deg)
   "d":[1200,1350,...]} <- distances in mm (integers)

Uplink (ground station -> robot)
---------------------------------
The SiK radio is full-duplex.  Incoming bytes are scanned for newline-
delimited JSON lines.  Any bytes that are NOT valid JSON lines are treated
as raw RTCM3 and forwarded to the TAU1308 via robot.inject_rtcm().

This mirrors how gnss/rtcm_serial.py works — the ground station dashboard
can send raw RTCM bytes and/or interleave JSON control messages.

Supported uplink JSON messages:
  {"t":"ping"}   -> ignored (keepalive)

robot.ini additions
-------------------
  [telemetry_radio]
  disabled     = false
  port         = /dev/ttyUSB1   ; SiK radio port (check: ls /dev/ttyUSB*)
  baud         = 57600          ; must match SiK ATS1 param on both radios
  telemetry_hz = 5              ; state packet downlink rate
  lidar        = true           ; include subsampled LiDAR at 1 Hz
  lidar_step   = 5              ; degrees between LiDAR samples (1-45)

  [rtcm]
  disabled     = true           ; serial_telemetry.py owns the SiK port

Usage
-----
  python3 tools/serial_telemetry.py
  python3 tools/serial_telemetry.py --port /dev/ttyUSB1 --baud 115200
  python3 tools/serial_telemetry.py --no-lidar
  python3 tools/serial_telemetry.py --no-camera --no-gps   # bench test
"""

import argparse
import configparser
import json
import logging
import os
import signal
import sys
import threading
import time

log = logging.getLogger("serial_telemetry")


# ── config helpers ────────────────────────────────────────────────────────────

def _cfg(cfg, section, key, fallback, cast=str):
    try:
        v = cfg.get(section, key).split('#')[0].strip()
        return cast(v) if v else fallback
    except Exception:
        return fallback


def _cfg_bool(cfg, section, key, fallback: bool) -> bool:
    try:
        v = cfg.get(section, key).split('#')[0].strip().lower()
        return v not in ('false', '0', 'no', 'off')
    except Exception:
        return fallback


# ── state serialisers ─────────────────────────────────────────────────────────

def _state_to_dict(state) -> dict:
    t = state.telemetry
    g = state.gps
    s = state.system
    return {
        "t":    "state",
        "ts":   round(time.monotonic(), 3),
        "mode": state.mode.name,
        "rc":   state.rc_active,
        "drv":  [round(state.drive.left, 3), round(state.drive.right, 3)],
        "telem": {
            "v":   round(t.voltage, 2),
            "i":   round(t.current, 2),
            "bt":  round(t.board_temp, 1),
            "lt":  round(t.left_temp, 1),
            "rt":  round(t.right_temp, 1),
            "lf":  t.left_fault,
            "rf":  t.right_fault,
            "hdg": round(t.heading, 1) if t.heading is not None else None,
            "pit": round(t.pitch,   1) if t.pitch   is not None else None,
            "rol": round(t.roll,    1) if t.roll    is not None else None,
        },
        "gps": {
            "lat":   round(g.latitude,  7) if g.latitude  is not None else None,
            "lon":   round(g.longitude, 7) if g.longitude is not None else None,
            "alt":   round(g.altitude,  1) if g.altitude  is not None else None,
            "spd":   round(g.speed,     2) if g.speed     is not None else None,
            "hdg":   round(g.heading,   1) if g.heading   is not None else None,
            "fix":   g.fix_quality,
            "fqn":   g.fix_quality_name,
            "herr":  round(g.h_error_m, 3) if g.h_error_m is not None else None,
            "sats":  g.satellites,
            "hdop":  round(g.hdop, 2)      if g.hdop      is not None else None,
            "ntrip": g.ntrip_status,
        },
        "sys": {
            "cpu":  round(s.cpu_percent, 1),
            "temp": round(s.cpu_temp_c,  1),
            "mem":  round(s.mem_percent, 1),
            "disk": round(s.disk_percent, 1),
        },
        "nav": {
            "st":   state.nav_state,
            "gate": state.nav_gate,
            "wp":   state.nav_wp,
            "dist": round(state.nav_wp_dist,     1) if state.nav_wp_dist     is not None else None,
            "bear": round(state.nav_wp_bear,     1) if state.nav_wp_bear     is not None else None,
            "berr": round(state.nav_bearing_err, 1) if state.nav_bearing_err is not None else None,
            "tags": state.nav_tags_visible,
        },
        "flags": {
            "lidar_ok": state.lidar_ok,
            "gps_ok":   state.gps_ok,
            "cam_ok":   state.camera_ok,
            "data_log": state.data_logging,
            "speed":    round(state.speed_scale, 2),
        },
    }


def _lidar_to_dict(scan, step: int) -> dict:
    angles_out: list[int] = []
    dists_out:  list[int] = []

    if scan.angles and scan.distances:
        lut: dict[int, float] = {}
        for a, d in zip(scan.angles, scan.distances):
            deg = int(round(a)) % 360
            if deg not in lut or d < lut[deg]:
                lut[deg] = d
        for deg in range(0, 360, step):
            angles_out.append(deg)
            dists_out.append(int(lut.get(deg, 0)))

    return {
        "t":  "lidar",
        "ts": round(time.monotonic(), 3),
        "a":  angles_out,
        "d":  dists_out,
    }


# ── bridge ────────────────────────────────────────────────────────────────────

class SerialTelemetry:
    """
    Owns the SiK radio serial port.

    TX thread  — serialises RobotState -> compact JSON -> radio at
                 telemetry_hz.  LiDAR packets at 1 Hz when lidar_enabled.

    RX thread  — reads incoming bytes from the radio.
                 Lines that parse as JSON are handled as control messages.
                 All other bytes are treated as raw RTCM3 and forwarded to
                 the TAU1308 via robot.inject_rtcm().
    """

    def __init__(self, robot, port: str, baud: int,
                 telemetry_hz: float, lidar_enabled: bool, lidar_step: int):
        self._robot        = robot
        self._port         = port
        self._baud         = baud
        self._hz           = telemetry_hz
        self.lidar_enabled = lidar_enabled   # public — toggle at runtime
        self._lidar_step   = lidar_step

        self._ser          = None
        self._stop         = threading.Event()
        self._tx_thread: threading.Thread | None = None
        self._rx_thread: threading.Thread | None = None
        self._tx_lock      = threading.Lock()

        # Stats
        self.rtcm_bytes_forwarded = 0
        self.packets_sent         = 0

    # ── lifecycle ─────────────────────────────────────────────────────────────

    def start(self):
        import serial
        log.info("Opening SiK radio on %s @ %d baud", self._port, self._baud)
        self._ser = serial.Serial(self._port, self._baud,
                                  timeout=0.05, write_timeout=1.0)
        time.sleep(0.3)
        self._ser.reset_input_buffer()

        self._tx_thread = threading.Thread(target=self._tx_loop,
                                           daemon=True, name="sik_tx")
        self._rx_thread = threading.Thread(target=self._rx_loop,
                                           daemon=True, name="sik_rx")
        self._tx_thread.start()
        self._rx_thread.start()
        log.info("SiK bridge started  lidar=%s step=%d°",
                 self.lidar_enabled, self._lidar_step)

    def stop(self):
        self._stop.set()
        for t in (self._tx_thread, self._rx_thread):
            if t and t.is_alive():
                t.join(timeout=2.0)
        try:
            if self._ser:
                self._ser.close()
        except Exception:
            pass
        log.info("SiK bridge stopped  rtcm_fwd=%d B  pkts_sent=%d",
                 self.rtcm_bytes_forwarded, self.packets_sent)

    # ── TX ────────────────────────────────────────────────────────────────────

    def _send_json(self, obj: dict):
        try:
            data = (json.dumps(obj, separators=(',', ':')) + '\n').encode()
            with self._tx_lock:
                self._ser.write(data)
            self.packets_sent += 1
        except Exception as e:
            log.warning("SiK TX error: %s", e)

    def _tx_loop(self):
        period       = 1.0 / self._hz
        lidar_period = 1.0
        next_tick    = time.monotonic()
        next_lidar   = time.monotonic()

        while not self._stop.is_set():
            now = time.monotonic()

            # State packet
            try:
                self._send_json(_state_to_dict(self._robot.get_state()))
            except Exception as e:
                log.debug("State serialise error: %s", e)

            # LiDAR packet (1 Hz, when enabled)
            if self.lidar_enabled and now >= next_lidar:
                try:
                    scan = self._robot.get_state().lidar
                    self._send_json(_lidar_to_dict(scan, self._lidar_step))
                except Exception as e:
                    log.debug("LiDAR serialise error: %s", e)
                next_lidar = now + lidar_period

            next_tick += period
            sleep_for  = next_tick - time.monotonic()
            if sleep_for > 0:
                time.sleep(sleep_for)
            else:
                next_tick = time.monotonic()

    # ── RX ────────────────────────────────────────────────────────────────────

    def _rx_loop(self):
        """
        Scan the uplink byte stream for newline-terminated lines.

        Lines that start with '{' and parse as JSON -> control message.
        Everything else -> raw RTCM3 bytes, forwarded to TAU1308.

        RTCM3 is binary (0xD3 preamble) and will almost never form valid
        UTF-8 JSON.  The rare case where a RTCM payload byte is 0x0A
        (newline) is handled gracefully: the fragment fails JSON parsing
        and is forwarded as raw bytes.
        """
        buf = bytearray()

        while not self._stop.is_set():
            try:
                chunk = self._ser.read(512)
            except Exception as e:
                log.warning("SiK RX error: %s", e)
                time.sleep(1.0)
                continue

            if not chunk:
                continue

            buf.extend(chunk)

            # Process all complete lines
            while b'\n' in buf:
                line, buf = buf.split(b'\n', 1)
                line_s = line.strip()
                if not line_s:
                    continue

                if line_s.startswith(b'{'):
                    try:
                        msg = json.loads(line_s)
                        self._handle_json(msg)
                        continue
                    except json.JSONDecodeError:
                        pass

                # Not JSON — forward as RTCM (restore the newline we split on)
                self._forward_rtcm(bytes(line) + b'\n')

            # Flush large non-JSON accumulations (RTCM without 0x0A bytes)
            if len(buf) > 512 and not buf.lstrip().startswith(b'{'):
                self._forward_rtcm(bytes(buf))
                buf = bytearray()

    def _forward_rtcm(self, data: bytes):
        if not data:
            return
        ok = self._robot.inject_rtcm(data)
        if ok:
            self.rtcm_bytes_forwarded += len(data)
            log.debug("RTCM fwd %d B (total %d B)",
                      len(data), self.rtcm_bytes_forwarded)
        else:
            log.debug("RTCM dropped — GPS unavailable (%d B)", len(data))

    def _handle_json(self, msg: dict):
        t = msg.get("t")
        if t == "ping":
            pass  # keepalive
        else:
            log.debug("Unknown uplink JSON type: %r", t)


# ── entry point ───────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="SiK radio telemetry bridge for HackyRacingRobot")
    ap.add_argument("--config",     default="robot.ini")
    ap.add_argument("--port",       default=None,
                    help="SiK radio serial port (overrides robot.ini)")
    ap.add_argument("--baud",       default=None, type=int)
    ap.add_argument("--hz",         default=None, type=float,
                    help="Telemetry packet rate Hz (overrides robot.ini)")
    ap.add_argument("--no-lidar",   action="store_true")
    ap.add_argument("--lidar-step", default=None, type=int,
                    help="LiDAR angular step degrees (default 5)")
    ap.add_argument("--no-camera",  action="store_true")
    ap.add_argument("--no-gps",     action="store_true",
                    help="Disable GPS — RTCM uplink will be dropped")
    ap.add_argument("--no-motors",  action="store_true")
    ap.add_argument("--log-level",  default="INFO")
    args = ap.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    cfg = configparser.ConfigParser()
    cfg.read(args.config)

    sik_port   = args.port       or _cfg(cfg, "telemetry_radio", "port",         "/dev/ttyUSB1")
    sik_baud   = args.baud       or _cfg(cfg, "telemetry_radio", "baud",         57600,  cast=int)
    telem_hz   = args.hz         or _cfg(cfg, "telemetry_radio", "telemetry_hz", 5.0,    cast=float)
    lidar_step = args.lidar_step or _cfg(cfg, "telemetry_radio", "lidar_step",   5,      cast=int)
    lidar_on   = (not args.no_lidar and
                  _cfg_bool(cfg, "telemetry_radio", "lidar", True))

    log.info("SiK port=%s  baud=%d  hz=%.1f  lidar=%s (step=%d°)",
             sik_port, sik_baud, telem_hz, lidar_on, lidar_step)

    # Build robot config dict from ini, apply CLI overrides
    robot_cfg = {s: dict(cfg[s]) for s in cfg.sections()}

    if args.no_camera:
        for sec in ("camera", "camera_front_left",
                    "camera_front_right", "camera_rear"):
            robot_cfg.setdefault(sec, {})["disabled"] = "true"
    if args.no_gps:
        robot_cfg.setdefault("gps", {})["disabled"] = "true"

    # Force [rtcm] disabled — we own the SiK port
    robot_cfg.setdefault("rtcm", {})["disabled"] = "true"

    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from robot_daemon import Robot
    from robot_utils import setup_logging
    setup_logging()

    robot = Robot(robot_cfg, no_motors=args.no_motors)

    bridge = SerialTelemetry(
        robot         = robot,
        port          = sik_port,
        baud          = sik_baud,
        telemetry_hz  = telem_hz,
        lidar_enabled = lidar_on,
        lidar_step    = lidar_step,
    )

    def _shutdown(sig, frame):
        log.info("Shutting down")
        bridge.stop()
        robot.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT,  _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    robot.start()
    bridge.start()

    log.info("Running — Ctrl+C to stop")
    while True:
        time.sleep(1.0)


if __name__ == "__main__":
    main()
