#!/usr/bin/env python3
"""
tools/robot_dashboard.py — Ground station dashboard for HackyRacingRobot.

Receives telemetry JSON from the SiK radio, displays live robot state, shows
an FPV camera feed (local USB capture card / V4L2 device), and forwards NTRIP
RTK corrections back to the robot via the same radio link.

Requires : pygame pyserial opencv-python
Optional  : (NTRIP client is built-in — no extra deps)

Layout (FPV mode, default)
--------------------------
  ┌─────────────────────────┬──────────────────┐
  │                         │ [1] TELEMETRY    │
  │   FPV FEED              ├──────────────────┤
  │   (fills left, 16:9     │ [2] GPS          │
  │    letterboxed)         ├──────────────────┤
  │                         │ [3] NAVIGATION   │
  │                         ├──────────────────┤
  │                         │ [4] LIDAR        │
  └─────────────────────────┴──────────────────┘
  │ status bar                                 │

Layout (no FPV, 2×2 grid)
--------------------------
  ┌─────────────────────────┬─────────────────┐
  │ [1] TELEMETRY           │ [2] GPS         │
  ├─────────────────────────┼─────────────────┤
  │ [3] NAVIGATION          │ [4] LIDAR       │
  └─────────────────────────┴─────────────────┘

Keys
----
  F        toggle FPV feed
  L        toggle LiDAR panel
  1-4      collapse/expand individual panels
  Q / Esc  quit

Usage
-----
  python3 tools/robot_dashboard.py
  python3 tools/robot_dashboard.py --port /dev/ttyUSB0
  python3 tools/robot_dashboard.py --port COM5            # Windows
  python3 tools/robot_dashboard.py --fpv-device 1         # second capture card
  python3 tools/robot_dashboard.py --no-ntrip             # telemetry only
  python3 tools/robot_dashboard.py --no-fpv               # no camera
"""

import argparse
import base64
import json
import math
import os
import queue
import signal
import socket
import sys
import threading
import time
from dataclasses import dataclass, field
from typing import Optional

try:
    import pygame
except ImportError:
    sys.exit("pygame not found — pip install pygame")

try:
    import serial
except ImportError:
    sys.exit("pyserial not found — pip install pyserial")

try:
    import cv2
    _CV2 = True
except ImportError:
    _CV2 = False

# ── colours ───────────────────────────────────────────────────────────────────
BLACK   = (  0,   0,   0)
WHITE   = (255, 255, 255)
GREY    = ( 80,  80,  80)
LGREY   = (120, 120, 120)
DGREY   = ( 22,  22,  28)
PANEL_BG= ( 30,  32,  38)
HDR_BG  = ( 45,  48,  58)
RED     = (220,  50,  50)
GREEN   = ( 50, 200,  80)
YELLOW  = (220, 200,  50)
ORANGE  = (220, 130,  40)
CYAN    = ( 50, 210, 210)
BLUE    = ( 60, 120, 220)

MODE_COLOUR = {"MANUAL": GREEN, "AUTO": CYAN, "ESTOP": RED}
FIX_COLOUR  = {0: RED, 1: YELLOW, 2: ORANGE, 4: GREEN, 5: CYAN}

STATUS_H   = 28
SIDEBAR_W  = 400
HEADER_H   = 26
COLLAPSED_H = HEADER_H


# ══════════════════════════════════════════════════════════════════════════════
# NTRIP client
# ══════════════════════════════════════════════════════════════════════════════

class NtripClient:
    def __init__(self, host, port, mount, user, password,
                 lat, lon, alt, rtcm_queue):
        self._host, self._port   = host, port
        self._mount              = mount
        self._user, self._password = user, password
        self._lat, self._lon, self._alt = lat, lon, alt
        self._q                  = rtcm_queue
        self._stop               = threading.Event()
        self.status              = "disconnected"
        self.bytes_recv          = 0
        threading.Thread(target=self._run, daemon=True, name="ntrip").start()

    def stop(self):
        self._stop.set()

    def _gga(self):
        lat, lon = abs(self._lat), abs(self._lon)
        ns = 'N' if self._lat >= 0 else 'S'
        ew = 'E' if self._lon >= 0 else 'W'
        gga = (f"GPGGA,{time.strftime('%H%M%S')}.00,"
               f"{int(lat):02d}{(lat-int(lat))*60:07.4f},{ns},"
               f"{int(lon):03d}{(lon-int(lon))*60:07.4f},{ew},"
               f"1,08,1.0,{self._alt:.1f},M,0.0,M,,")
        ck = 0
        for c in gga: ck ^= ord(c)
        return f"${gga}*{ck:02X}\r\n"

    def _run(self):
        cred = base64.b64encode(
            f"{self._user}:{self._password}".encode()).decode()
        while not self._stop.is_set():
            self.status = "connecting"
            try:
                sock = socket.create_connection(
                    (self._host, self._port), timeout=10)
                req = (f"GET /{self._mount} HTTP/1.0\r\n"
                       f"Host: {self._host}\r\n"
                       f"User-Agent: HackyRacingRobot/1.0\r\n"
                       f"Authorization: Basic {cred}\r\n"
                       f"Ntrip-Version: Ntrip/2.0\r\n\r\n")
                sock.sendall(req.encode())
                resp = b""
                while b"\r\n\r\n" not in resp:
                    resp += sock.recv(256)
                if b"200" not in resp and b"ICY 200" not in resp:
                    raise ConnectionError(f"Bad response: {resp[:60]}")
                sock.sendall(self._gga().encode())
                self.status = "connected"
                last_gga = time.monotonic()
                sock.settimeout(5.0)
                while not self._stop.is_set():
                    try:
                        chunk = sock.recv(1024)
                    except socket.timeout:
                        if time.monotonic() - last_gga > 30:
                            sock.sendall(self._gga().encode())
                            last_gga = time.monotonic()
                        continue
                    if not chunk:
                        raise ConnectionError("Connection closed")
                    self.bytes_recv += len(chunk)
                    self._q.put(chunk)
            except Exception as e:
                self.status = f"error"
                time.sleep(5)


# ══════════════════════════════════════════════════════════════════════════════
# Radio link
# ══════════════════════════════════════════════════════════════════════════════

class RadioLink:
    def __init__(self, port, baud, state_q, lidar_q, rtcm_q):
        self._port, self._baud = port, baud
        self._state_q = state_q
        self._lidar_q = lidar_q
        self._rtcm_q  = rtcm_q
        self._ser     = None
        self._stop    = threading.Event()
        self._lock    = threading.Lock()
        self.packets_recv = 0
        self.last_rx_ts   = 0.0
        self.connected    = False

    def start(self):
        self._ser = serial.Serial(self._port, self._baud,
                                  timeout=0.1, write_timeout=1.0)
        time.sleep(0.3)
        self._ser.reset_input_buffer()
        self.connected = True
        threading.Thread(target=self._rx, daemon=True, name="radio_rx").start()
        threading.Thread(target=self._tx, daemon=True, name="radio_tx").start()

    def stop(self):
        self._stop.set()
        try:
            if self._ser: self._ser.close()
        except Exception:
            pass

    def _rx(self):
        buf = b""
        while not self._stop.is_set():
            try:
                chunk = self._ser.read(512)
            except Exception:
                time.sleep(1.0)
                continue
            if not chunk:
                continue
            buf += chunk
            while b'\n' in buf:
                line, buf = buf.split(b'\n', 1)
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                    self.packets_recv += 1
                    self.last_rx_ts = time.monotonic()
                    t = msg.get("t")
                    if t == "state":
                        self._put(self._state_q, msg)
                    elif t == "lidar":
                        self._put(self._lidar_q, msg)
                except json.JSONDecodeError:
                    pass

    @staticmethod
    def _put(q, item):
        try:
            q.put_nowait(item)
        except queue.Full:
            try: q.get_nowait()
            except queue.Empty: pass
            q.put_nowait(item)

    def _tx(self):
        CHUNK = 200
        pending = b""
        while not self._stop.is_set():
            try:
                data = self._rtcm_q.get(timeout=0.05)
                pending += data
            except queue.Empty:
                if pending:
                    self._send_rtcm(pending)
                    pending = b""
                continue
            while len(pending) >= CHUNK:
                self._send_rtcm(pending[:CHUNK])
                pending = pending[CHUNK:]

    def _send_rtcm(self, data: bytes):
        # Send raw bytes directly — serial_telemetry.py RX loop handles them
        try:
            with self._lock:
                self._ser.write(data)
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════════
# FPV capture thread
# ══════════════════════════════════════════════════════════════════════════════

class FpvCapture:
    """
    Opens a local webcam / capture card with OpenCV and maintains the latest
    frame as a pygame Surface, ready to blit.
    """

    def __init__(self, device):
        self._device  = device
        self._surface: Optional[pygame.Surface] = None
        self._lock    = threading.Lock()
        self._stop    = threading.Event()
        self.ok       = False
        self.width    = 0
        self.height   = 0
        threading.Thread(target=self._run, daemon=True, name="fpv").start()

    def stop(self):
        self._stop.set()

    def get_surface(self) -> Optional[pygame.Surface]:
        with self._lock:
            return self._surface

    def _run(self):
        if not _CV2:
            return

        # Accept int index or string path
        try:
            dev = int(self._device)
        except (ValueError, TypeError):
            dev = self._device

        cap = cv2.VideoCapture(dev)
        if not cap.isOpened():
            return

        self.ok = True
        while not self._stop.is_set():
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.05)
                continue
            # BGR -> RGB
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w = frame_rgb.shape[:2]
            surf = pygame.surfarray.make_surface(
                frame_rgb.transpose(1, 0, 2))
            with self._lock:
                self._surface = surf
                self.width    = w
                self.height   = h

        cap.release()
        self.ok = False


# ══════════════════════════════════════════════════════════════════════════════
# Collapsible panel
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class Panel:
    title:     str
    key:       int          # pygame key constant
    collapsed: bool = False
    enabled:   bool = True  # False = hidden entirely

    def toggle_collapse(self):
        self.collapsed = not self.collapsed

    def header_height(self) -> int:
        return HEADER_H

    def effective_height(self, allocated: int) -> int:
        return COLLAPSED_H if self.collapsed else allocated


# ══════════════════════════════════════════════════════════════════════════════
# Dashboard
# ══════════════════════════════════════════════════════════════════════════════

class Dashboard:

    WIN_W, WIN_H = 1280, 720

    def __init__(self, link: RadioLink,
                 ntrip: Optional[NtripClient],
                 fpv: Optional[FpvCapture],
                 state_q: queue.Queue,
                 lidar_q: queue.Queue):
        self._link    = link
        self._ntrip   = ntrip
        self._fpv     = fpv
        self._state_q = state_q
        self._lidar_q = lidar_q

        self._state   = None
        self._lidar   = None
        self._lidar_ts = 0.0

        self._fpv_on  = fpv is not None

        pygame.init()
        self._screen = pygame.display.set_mode(
            (self.WIN_W, self.WIN_H), pygame.RESIZABLE)
        pygame.display.set_caption("HackyRacingRobot — Ground Station")

        self._font_xl = pygame.font.SysFont("monospace", 24, bold=True)
        self._font_l  = pygame.font.SysFont("monospace", 19, bold=True)
        self._font_m  = pygame.font.SysFont("monospace", 15)
        self._font_s  = pygame.font.SysFont("monospace", 12)
        self._clock   = pygame.time.Clock()

        self._panels = [
            Panel("TELEMETRY",  pygame.K_1),
            Panel("GPS",        pygame.K_2),
            Panel("NAVIGATION", pygame.K_3),
            Panel("LIDAR",      pygame.K_4),
        ]

    # ── main loop ─────────────────────────────────────────────────────────────

    def run(self):
        while True:
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:
                    return
                if ev.type == pygame.VIDEORESIZE:
                    self.WIN_W, self.WIN_H = ev.w, ev.h
                if ev.type == pygame.KEYDOWN:
                    self._handle_key(ev.key)

            # Drain queues
            try:
                self._state = self._state_q.get_nowait()
            except queue.Empty:
                pass
            try:
                self._lidar    = self._lidar_q.get_nowait()
                self._lidar_ts = time.monotonic()
            except queue.Empty:
                pass

            self._draw()
            self._clock.tick(20)

    def _handle_key(self, key):
        if key in (pygame.K_q, pygame.K_ESCAPE):
            pygame.event.post(pygame.event.Event(pygame.QUIT))
        elif key == pygame.K_f:
            self._fpv_on = not self._fpv_on and self._fpv is not None
        elif key == pygame.K_l:
            self._panels[3].enabled = not self._panels[3].enabled
        else:
            for p in self._panels:
                if key == p.key:
                    p.toggle_collapse()

    # ── layout ────────────────────────────────────────────────────────────────

    def _draw(self):
        W, H = self.WIN_W, self.WIN_H
        content_h = H - STATUS_H
        self._screen.fill(DGREY)

        if self._fpv_on and self._fpv:
            self._draw_fpv_layout(W, content_h)
        else:
            self._draw_grid_layout(W, content_h)

        self._draw_status_bar(W, H)
        pygame.display.flip()

    # ── FPV layout: feed left, panels stacked right ───────────────────────────

    def _draw_fpv_layout(self, W: int, content_h: int):
        sidebar_w = min(SIDEBAR_W, W // 3)
        feed_w    = W - sidebar_w

        # FPV feed
        feed_rect = pygame.Rect(0, 0, feed_w, content_h)
        self._draw_fpv(feed_rect)

        # Sidebar panels
        self._draw_sidebar(feed_w, 0, sidebar_w, content_h)

    def _draw_sidebar(self, x: int, y: int, w: int, total_h: int):
        visible = [p for p in self._panels if p.enabled]
        if not visible:
            return

        # Distribute height: expanded panels share remaining space equally
        n_collapsed  = sum(1 for p in visible if p.collapsed)
        n_expanded   = len(visible) - n_collapsed
        collapsed_total = n_collapsed * COLLAPSED_H
        expanded_h = ((total_h - collapsed_total) // n_expanded
                      if n_expanded else 0)
        expanded_h = max(expanded_h, COLLAPSED_H + 20)

        cy = y
        for i, p in enumerate(self._panels):
            if not p.enabled:
                continue
            ph = COLLAPSED_H if p.collapsed else expanded_h
            rect = pygame.Rect(x, cy, w, ph)
            self._draw_panel(rect, p, i)
            cy += ph

    def _draw_grid_layout(self, W: int, content_h: int):
        half_w = W // 2
        half_h = content_h // 2
        rects = [
            pygame.Rect(0,      0,      half_w, half_h),
            pygame.Rect(half_w, 0,      half_w, half_h),
            pygame.Rect(0,      half_h, half_w, half_h),
            pygame.Rect(half_w, half_h, half_w, half_h),
        ]
        for i, p in enumerate(self._panels):
            if p.enabled:
                self._draw_panel(rects[i], p, i)

    # ── panel renderer ────────────────────────────────────────────────────────

    def _draw_panel(self, rect: pygame.Rect, panel: Panel, idx: int):
        pygame.draw.rect(self._screen, PANEL_BG, rect)
        pygame.draw.rect(self._screen, GREY, rect, 1)

        # Header bar
        hdr = pygame.Rect(rect.x, rect.y, rect.w, HEADER_H)
        pygame.draw.rect(self._screen, HDR_BG, hdr)
        key_hint = f"[{idx+1}]"
        caret    = "▶" if panel.collapsed else "▼"
        title    = f" {caret} {key_hint} {panel.title}"
        self._screen.blit(
            self._font_s.render(title, True, LGREY), (hdr.x + 4, hdr.y + 6))

        if panel.collapsed or rect.h <= HEADER_H + 4:
            return

        # Content area
        content = pygame.Rect(rect.x + 4, rect.y + HEADER_H + 4,
                              rect.w - 8, rect.h - HEADER_H - 8)

        s = self._state
        if panel.title == "TELEMETRY":
            if s: self._draw_telemetry(content, s)
        elif panel.title == "GPS":
            if s: self._draw_gps(content, s)
        elif panel.title == "NAVIGATION":
            if s: self._draw_nav(content, s)
        elif panel.title == "LIDAR":
            self._draw_lidar(content)

        if not s and panel.title != "LIDAR":
            txt = self._font_l.render("NO SIGNAL", True, RED)
            self._screen.blit(txt,
                (content.centerx - txt.get_width() // 2,
                 content.centery - txt.get_height() // 2))

    # ── FPV feed ──────────────────────────────────────────────────────────────

    def _draw_fpv(self, rect: pygame.Rect):
        pygame.draw.rect(self._screen, BLACK, rect)

        surf = self._fpv.get_surface() if self._fpv else None
        if surf is None:
            msg = ("No FPV signal" if _CV2
                   else "opencv-python not installed")
            txt = self._font_l.render(msg, True, GREY)
            self._screen.blit(txt,
                (rect.centerx - txt.get_width() // 2,
                 rect.centery - txt.get_height() // 2))
            return

        # Letterbox: scale to fit rect preserving aspect ratio
        sw, sh = surf.get_size()
        scale  = min(rect.w / sw, rect.h / sh)
        dw     = int(sw * scale)
        dh     = int(sh * scale)
        ox     = rect.x + (rect.w - dw) // 2
        oy     = rect.y + (rect.h - dh) // 2

        scaled = pygame.transform.scale(surf, (dw, dh))
        self._screen.blit(scaled, (ox, oy))

        # Overlay: FPV label and resolution
        ok_col = GREEN if (self._fpv and self._fpv.ok) else RED
        label  = self._font_s.render(
            f"FPV  {self._fpv.width}×{self._fpv.height}  [F to hide]",
            True, ok_col)
        self._screen.blit(label, (rect.x + 6, rect.y + 4))

    # ── telemetry panel content ───────────────────────────────────────────────

    def _draw_telemetry(self, rect: pygame.Rect, s: dict):
        x, y = rect.x, rect.y
        tl   = s.get("telem", {})
        fl   = s.get("flags", {})
        dr   = s.get("drv", [0.0, 0.0])

        mode   = s.get("mode", "?")
        mc     = MODE_COLOUR.get(mode, WHITE)
        y = self._text(f"● {mode}", mc, x, y, self._font_l); y += 4

        y = self._drive_bars(x, y, rect.w, dr[0], dr[1]); y += 6

        v   = tl.get("v", 0.0)
        vc  = GREEN if v > 11.0 else (YELLOW if v > 10.5 else RED)
        y = self._row("Voltage",  f"{v:.2f} V",               x, y, vc)
        y = self._row("Current",  f"{tl.get('i',0):.2f} A",   x, y)
        y = self._row("Bd Temp",  f"{tl.get('bt',0):.1f} °C", x, y)
        y = self._row("L Temp",   f"{tl.get('lt',0):.1f} °C", x, y)
        y = self._row("R Temp",   f"{tl.get('rt',0):.1f} °C", x, y)

        lf, rf = tl.get("lf", False), tl.get("rf", False)
        fc = RED if (lf or rf) else GREEN
        y = self._row("Faults",
                      f"L:{'FAULT' if lf else 'ok'}  R:{'FAULT' if rf else 'ok'}",
                      x, y, fc)

        hdg = tl.get("hdg")
        pit = tl.get("pit")
        rol = tl.get("rol")
        y = self._row("Heading", f"{hdg:.1f}°" if hdg is not None else "—", x, y, CYAN)
        y = self._row("Pitch",   f"{pit:.1f}°" if pit is not None else "—", x, y)
        y = self._row("Roll",    f"{rol:.1f}°" if rol is not None else "—", x, y)
        y = self._row("Speed",   f"{fl.get('speed',0)*100:.0f}%",           x, y)
        y = self._row("RC",      "active" if s.get("rc") else "LOST",       x, y,
                      GREEN if s.get("rc") else RED)

    def _drive_bars(self, x: int, y: int, panel_w: int,
                    left: float, right: float) -> int:
        bar_w = min(140, (panel_w - 20) // 2)
        bar_h = 16
        for val, label, bx in ((left,  "L", x),
                                (right, "R", x + bar_w + 8)):
            pygame.draw.rect(self._screen, GREY, (bx, y, bar_w, bar_h))
            filled = int(abs(val) * bar_w // 2)
            col    = GREEN if val >= 0 else RED
            ox     = bx + bar_w // 2
            if val >= 0:
                pygame.draw.rect(self._screen, col, (ox, y, filled, bar_h))
            else:
                pygame.draw.rect(self._screen, col,
                                 (ox - filled, y, filled, bar_h))
            # Centre line
            pygame.draw.line(self._screen, LGREY,
                             (ox, y), (ox, y + bar_h), 1)
            lbl = self._font_s.render(f"{label}{val:+.2f}", True, WHITE)
            self._screen.blit(lbl, (bx + 2, y + 1))
        return y + bar_h + 2

    # ── GPS panel content ─────────────────────────────────────────────────────

    def _draw_gps(self, rect: pygame.Rect, s: dict):
        x, y = rect.x, rect.y
        g    = s.get("gps", {})

        fq  = g.get("fix", 0)
        fc  = FIX_COLOUR.get(fq, GREY)
        y = self._text(f"● {g.get('fqn','Invalid')}", fc, x, y, self._font_l)
        y += 4

        lat  = g.get("lat");  lon  = g.get("lon")
        alt  = g.get("alt");  spd  = g.get("spd")
        hdg  = g.get("hdg");  herr = g.get("herr")
        sats = g.get("sats"); hdop = g.get("hdop")
        ntrip = g.get("ntrip", "")

        y = self._row("Latitude",  f"{lat:.7f}°"  if lat  is not None else "—", x, y, CYAN)
        y = self._row("Longitude", f"{lon:.7f}°"  if lon  is not None else "—", x, y, CYAN)
        y = self._row("Altitude",  f"{alt:.1f} m" if alt  is not None else "—", x, y)
        y = self._row("Speed",     f"{spd:.2f} m/s" if spd is not None else "—", x, y)
        y = self._row("Heading",   f"{hdg:.1f}°"  if hdg  is not None else "—", x, y)
        ec = (GREEN if herr is not None and herr < 0.05
              else YELLOW if herr is not None else GREY)
        y = self._row("H Error",
                      f"{herr:.3f} m" if herr is not None else "—", x, y, ec)
        y = self._row("Satellites", str(sats) if sats is not None else "—", x, y)
        y = self._row("HDOP",      f"{hdop:.2f}" if hdop is not None else "—", x, y)

        nc = (GREEN   if ntrip == "connected"
              else YELLOW if "connect" in ntrip
              else RED)
        y = self._row("NTRIP", ntrip or "—", x, y, nc)

        if self._ntrip:
            nb = self._ntrip.bytes_recv
            y = self._row("RTCM recv",
                          f"{nb//1024} KB" if nb > 1024 else f"{nb} B",
                          x, y, CYAN)

    # ── navigation panel content ──────────────────────────────────────────────

    def _draw_nav(self, rect: pygame.Rect, s: dict):
        x, y = rect.x, rect.y
        nav  = s.get("nav", {})
        fl   = s.get("flags", {})

        st  = nav.get("st", "IDLE")
        sc  = CYAN if st not in ("IDLE", "ESTOP") else LGREY
        y = self._text(st, sc, x, y, self._font_l); y += 4

        y = self._row("Gate",     str(nav.get("gate", 0)), x, y)
        y = self._row("Waypoint", str(nav.get("wp",   0)), x, y)

        dist = nav.get("dist")
        y = self._row("WP Dist",
                      f"{dist:.1f} m" if dist is not None else "—", x, y)
        bear = nav.get("bear")
        y = self._row("WP Bear",
                      f"{bear:.1f}°" if bear is not None else "—", x, y)
        berr = nav.get("berr")
        bc   = GREEN if berr is not None and abs(berr) < 5 else YELLOW
        y = self._row("Bear Err",
                      f"{berr:.1f}°" if berr is not None else "—", x, y, bc)
        y = self._row("Tags vis", str(nav.get("tags", 0)), x, y)

        y += 6
        for label, key, ok_val in (
            ("LiDAR",  "lidar_ok", True),
            ("GPS",    "gps_ok",   True),
            ("Camera", "cam_ok",   True),
            ("DataLog","data_log", True),
        ):
            v   = fl.get(key, False)
            col = (CYAN if label == "DataLog" and v
                   else GREEN if v else GREY)
            y = self._row(label,
                          "recording" if label == "DataLog" and v
                          else ("ok" if v else "off"),
                          x, y, col)

    # ── LiDAR polar panel content ─────────────────────────────────────────────

    def _draw_lidar(self, rect: pygame.Rect):
        cx = rect.centerx
        cy = rect.centery
        r  = max(10, min(rect.w, rect.h) // 2 - 10)

        for frac in (0.25, 0.5, 0.75, 1.0):
            pygame.draw.circle(self._screen, GREY, (cx, cy), int(r * frac), 1)
        pygame.draw.line(self._screen, GREY, (cx-r, cy), (cx+r, cy), 1)
        pygame.draw.line(self._screen, GREY, (cx, cy-r), (cx, cy+r), 1)

        lidar = self._lidar
        if not lidar:
            txt = self._font_s.render("Waiting for LiDAR…", True, GREY)
            self._screen.blit(txt,
                (cx - txt.get_width()//2, cy - txt.get_height()//2))
            return

        stale = time.monotonic() - self._lidar_ts > 3.0
        col   = GREY if stale else GREEN

        dists = lidar.get("d", [])
        max_d = max((d for d in dists if d > 0), default=5000)

        for ang, dist in zip(lidar.get("a", []), dists):
            if dist <= 0:
                continue
            rad = math.radians(ang - 90)
            sc  = min(dist / max_d, 1.0)
            px  = cx + int(math.cos(rad) * r * sc)
            py  = cy + int(math.sin(rad) * r * sc)
            pygame.draw.circle(self._screen, col, (px, py), 2)

        pygame.draw.circle(self._screen, WHITE, (cx, cy), 4)

        info = self._font_s.render(
            f"max {max_d/1000:.1f} m{'  STALE' if stale else ''}",
            True, GREY if stale else WHITE)
        self._screen.blit(info, (rect.x, rect.bottom - 16))

    # ── status bar ────────────────────────────────────────────────────────────

    def _draw_status_bar(self, W: int, H: int):
        bar = pygame.Rect(0, H - STATUS_H, W, STATUS_H)
        pygame.draw.rect(self._screen, BLACK, bar)
        pygame.draw.line(self._screen, GREY,
                         (0, H - STATUS_H), (W, H - STATUS_H), 1)

        age  = time.monotonic() - self._link.last_rx_ts
        lc   = GREEN if age < 1.0 else (YELLOW if age < 3.0 else RED)
        link = (f"● LINK  pkts:{self._link.packets_recv}"
                f"  age:{age:.1f}s  {self._link._port}@{self._link._baud}")
        self._screen.blit(self._font_s.render(link, True, lc),
                          (6, H - STATUS_H + 7))

        hints = "F=FPV  L=LiDAR  1-4=collapse  Q=quit"
        hs    = self._font_s.render(hints, True, GREY)
        self._screen.blit(hs, (W//2 - hs.get_width()//2, H - STATUS_H + 7))

        if self._ntrip:
            nc  = GREEN if self._ntrip.status == "connected" else YELLOW
            nb  = self._ntrip.bytes_recv
            nts = f"NTRIP:{self._ntrip.status}  {nb//1024}KB ●"
            ns  = self._font_s.render(nts, True, nc)
            self._screen.blit(ns, (W - ns.get_width() - 6, H - STATUS_H + 7))

    # ── text helpers ──────────────────────────────────────────────────────────

    def _text(self, txt: str, col, x: int, y: int, font=None) -> int:
        f = font or self._font_m
        s = f.render(txt, True, col)
        self._screen.blit(s, (x, y))
        return y + s.get_height() + 2

    def _row(self, label: str, value: str, x: int, y: int,
             val_col=WHITE) -> int:
        self._screen.blit(self._font_s.render(label, True, GREY),    (x,       y))
        self._screen.blit(self._font_s.render(value, True, val_col), (x + 110, y))
        return y + 17


# ══════════════════════════════════════════════════════════════════════════════
# Entry point
# ══════════════════════════════════════════════════════════════════════════════

def main():
    ap = argparse.ArgumentParser(
        description="HackyRacingRobot ground station dashboard")
    ap.add_argument("--port",           default="/dev/ttyUSB0",
                    help="SiK radio serial port (/dev/ttyUSB0 or COM5)")
    ap.add_argument("--baud",           default=57600, type=int)
    ap.add_argument("--no-ntrip",       action="store_true")
    ap.add_argument("--no-fpv",         action="store_true")
    ap.add_argument("--fpv-device",     default="0",
                    help="FPV capture device index or path (default 0)")
    # NTRIP options
    ap.add_argument("--ntrip-host",     default="www.rtk2go.com")
    ap.add_argument("--ntrip-port",     default=2101,  type=int)
    ap.add_argument("--ntrip-mount",    default="CAMBRIDGE")
    ap.add_argument("--ntrip-user",
                    default=os.environ.get("NTRIP_USER", "user@example.com"))
    ap.add_argument("--ntrip-password",
                    default=os.environ.get("NTRIP_PASSWORD", "none"))
    ap.add_argument("--ntrip-lat",      default=52.2,  type=float)
    ap.add_argument("--ntrip-lon",      default=0.1,   type=float)
    ap.add_argument("--ntrip-alt",      default=20.0,  type=float)
    args = ap.parse_args()

    state_q: queue.Queue = queue.Queue(maxsize=2)
    lidar_q: queue.Queue = queue.Queue(maxsize=2)
    rtcm_q:  queue.Queue = queue.Queue(maxsize=100)

    # Radio
    link = RadioLink(args.port, args.baud, state_q, lidar_q, rtcm_q)
    try:
        link.start()
        print(f"SiK radio: {args.port} @ {args.baud} baud")
    except Exception as e:
        sys.exit(f"Cannot open serial port {args.port}: {e}")

    # NTRIP
    ntrip = None
    if not args.no_ntrip:
        ntrip = NtripClient(
            host     = args.ntrip_host,
            port     = args.ntrip_port,
            mount    = args.ntrip_mount,
            user     = args.ntrip_user,
            password = args.ntrip_password,
            lat      = args.ntrip_lat,
            lon      = args.ntrip_lon,
            alt      = args.ntrip_alt,
            rtcm_queue = rtcm_q,
        )
        print(f"NTRIP: {args.ntrip_host}/{args.ntrip_mount}")

    # FPV
    fpv = None
    if not args.no_fpv:
        if not _CV2:
            print("WARNING: opencv-python not installed — FPV disabled")
            print("         pip install opencv-python")
        else:
            fpv = FpvCapture(args.fpv_device)
            print(f"FPV: device {args.fpv_device}")

    def _shutdown(sig, frame):
        link.stop()
        if ntrip: ntrip.stop()
        if fpv:   fpv.stop()
        pygame.quit()
        sys.exit(0)

    signal.signal(signal.SIGINT,  _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    dash = Dashboard(link=link, ntrip=ntrip, fpv=fpv,
                     state_q=state_q, lidar_q=lidar_q)
    dash.run()

    link.stop()
    if ntrip: ntrip.stop()
    if fpv:   fpv.stop()
    pygame.quit()


if __name__ == "__main__":
    main()
